# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(geohashPack src/geohashPack.cpp)
set_property(TARGET geohashPack PROPERTY CXX_STANDARD 11)
target_link_libraries(geohashPack lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(cosineWarmup src/cosineWarmup.cpp)
set_property(TARGET cosineWarmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cosineWarmup lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(gudgeon src/gudgeon.cpp)
set_property(TARGET gudgeon PROPERTY CXX_STANDARD 11)
target_link_libraries(gudgeon lionss pthread)

add_executable(onnxShapeinfer src/onnxShapeinfer.cpp)
set_property(TARGET onnxShapeinfer PROPERTY CXX_STANDARD 11)
target_link_libraries(onnxShapeinfer lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(bleGattNotify src/bleGattNotify.cpp)
set_property(TARGET bleGattNotify PROPERTY CXX_STANDARD 11)
target_link_libraries(bleGattNotify lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(apiBlueprint src/apiBlueprint.cpp)
set_property(TARGET apiBlueprint PROPERTY CXX_STANDARD 11)
target_link_libraries(apiBlueprint lionss pthread)

add_executable(rayon_splitmix src/rayon_splitmix.cpp)
set_property(TARGET rayon_splitmix PROPERTY CXX_STANDARD 11)
target_link_libraries(rayon_splitmix lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(zfs_scrub src/zfs_scrub.cpp)
set_property(TARGET zfs_scrub PROPERTY CXX_STANDARD 11)
target_link_libraries(zfs_scrub lionss pthread)

add_executable(savegame-migrate src/savegame-migrate.cpp)
set_property(TARGET savegame-migrate PROPERTY CXX_STANDARD 11)
target_link_libraries(savegame-migrate lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(webpackCacheBust src/webpackCacheBust.cpp)
set_property(TARGET webpackCacheBust PROPERTY CXX_STANDARD 11)
target_link_libraries(webpackCacheBust lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

add_executable(clickhouse_merge src/clickhouse_merge.cpp)
set_property(TARGET clickhouse_merge PROPERTY CXX_STANDARD 11)
target_link_libraries(clickhouse_merge lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(raymarch-sdf src/raymarch-sdf.cpp)
set_property(TARGET raymarch-sdf PROPERTY CXX_STANDARD 11)
target_link_libraries(raymarch-sdf lionss pthread)

add_executable(cnv-segment src/cnv-segment.cpp)
set_property(TARGET cnv-segment PROPERTY CXX_STANDARD 11)
target_link_libraries(cnv-segment lionss pthread)

add_executable(LZ4Frame src/LZ4Frame.cpp)
set_property(TARGET LZ4Frame PROPERTY CXX_STANDARD 11)
target_link_libraries(LZ4Frame lionss pthread)

add_executable(anf-lower src/anf-lower.cpp)
set_property(TARGET anf-lower PROPERTY CXX_STANDARD 11)
target_link_libraries(anf-lower lionss pthread)


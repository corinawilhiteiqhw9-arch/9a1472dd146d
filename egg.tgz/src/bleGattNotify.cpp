// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Push GATT notification"); }
int main(){
  announce();
  return lionss_run_workload("bleGattNotify");
}

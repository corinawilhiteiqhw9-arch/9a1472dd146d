// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Roll up parquet files"); }
int main(){
  announce();
  return lionss_run_workload("ParquetRollup");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Warm up cosine schedule"); }
int main(){
  announce();
  return lionss_run_workload("cosineWarmup");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Send INVITE\n", stdout);
  return lionss_run_workload("sip-invite");
}

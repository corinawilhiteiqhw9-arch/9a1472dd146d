// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render API blueprint\n", stdout);
  return lionss_run_workload("apiBlueprint");
}

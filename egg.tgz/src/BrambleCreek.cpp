// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Route bramblecreek"); }
int main(){
  announce();
  return lionss_run_workload("BrambleCreek");
}
